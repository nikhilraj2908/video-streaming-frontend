import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "@/contexts/ThemeContext";
import { Layout } from "@/components/layout/Layout";
import { Home } from "@/pages/Home";
import { VideoDetail } from "@/pages/VideoDetail";
import { Auth } from "@/pages/Auth";
import { Upload } from "@/pages/Upload";
import { Search } from "@/pages/Search";
import { Library } from "@/pages/Library";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/auth" element={<Auth />} />
            <Route path="/" element={
              <Layout>
                <Home />
              </Layout>
            } />
            <Route path="/watch/:id" element={
              <Layout>
                <VideoDetail />
              </Layout>
            } />
            <Route path="/upload" element={
              <Layout>
                <Upload />
              </Layout>
            } />
            <Route path="/search" element={
              <Layout>
                <Search />
              </Layout>
            } />
            <Route path="/library" element={
              <Layout>
                <Library />
              </Layout>
            } />
            <Route path="/subscriptions" element={
              <Layout>
                <Home />
              </Layout>
            } />
            <Route path="/trending" element={
              <Layout>
                <Home />
              </Layout>
            } />
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
